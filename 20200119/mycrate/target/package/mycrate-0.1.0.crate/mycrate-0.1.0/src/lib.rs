pub  mod islamabad
{
    pub fn piaic()
    {
        println!("This is a sample library");
        println!("To Test Crate.io publishing");
    }
}